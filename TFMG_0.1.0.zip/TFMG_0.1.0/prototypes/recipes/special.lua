data:extend({
  {
    type = "recipe",
    category = "special",
    name = "small-radiator-radiation",
    icon = "__base__/graphics/icons/signal/signal-fire.png",
    energy_required = 100,
    enabled = true,
    ingredients = {},
    results = {},--possible that i could use a spoiling output of a heat item to make a thermal efficiency mechanic?
  },
})