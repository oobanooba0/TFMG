data:extend({
    {
        type = "recipe-category",
        name = "matter-reconstructor"
    },
    {--matter reconstructor and Assembling machine, Early mall items here.
        type = "recipe-category",
        name = "basic-assembling"
    },
    {
        type = "recipe-category",
        name = "assembling-machine"
    },
    {
        type = "recipe-category",
        name = "furnace"
    },
    {
        type = "recipe-category",
        name = "special"--thermal and other secret recipes live here.
    },

})