The Factory Must Grow is intended to be a total overhaul mod for Factorio, which utilises and expands on the newly introduced mechanics in Space Age. It's intended to be provide unique and difficult chalanges for the veteran Factorio player, without being too grindy.


---Credits---

Contributors:

oobanooba

People who have helped me out:

Allison - For helping me make compound entities work for the thermal system

Dobberoonski - For teaching me about compound entities

Loup&Snoop - For helping me with compound entities

Mr.SmoothieHuman - for pointing me to the runtime docs, which i somehow missed because i am stoopid.

notnotmelon - for helping me with the spidertron deployment mechanic.


People who I never talked to but I'd like to thank anyway:

Corlin and Xiroc - Platformer Mod

Flib team - Flib is pretty nice.

NindyBun - Heat Powered production

raiguard + K2 team - Krastorio 2

Rseding91 - For various fourm posts that helped me out

SafTheLamb + S6X - Cupric-asteroids

Z4NON - Electric Heating Tower

One way or another, You have unwittingly helped me in this project.